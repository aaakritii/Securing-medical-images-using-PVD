#!/bin/bash
for f in {1..120}
do
    echo "$f" > "$f.txt"
done
